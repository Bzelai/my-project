package com.example.rankingproject.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.rankingproject.R;



public class HomeFragment extends Fragment {

    TextView name;
    // Add RecyclerView member
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_home, container, false);
        name = (TextView) view.findViewById(R.id.textView2);
        // Add the following lines to create RecyclerView



        return inflater.inflate(R.layout.fragment_home, container, false);
    }
}