package com.example.rankingproject;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;

public class login extends AppCompatActivity {

    private EditText Email, Password;
    private TextView Info, Signup;
    private Button Login;
    private Button logout;
    private int counter = 5;
    private FirebaseAuth firebase;
    FirebaseUser User;
    private ProgressDialog ProDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        getSupportActionBar().hide();//this line hide the action bar.
        Email = (EditText)findViewById(R.id.PTname);
        Password = (EditText)findViewById(R.id.Ppassword);
        Info = (TextView)findViewById(R.id.TVinfo);
        Login = (Button) findViewById(R.id.BTlogin);
        Signup = (TextView)findViewById((R.id.TVsingup));
        firebase = FirebaseAuth.getInstance();
        ProDialog = new ProgressDialog(this);
        User = firebase.getCurrentUser();

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProgressDialog pd = new ProgressDialog(login.this);
                pd.setMessage("Pleas wait...");
                pd.show();
                String str_email = Email.getText().toString();
                String str_password = Password.getText().toString();
                if(TextUtils.isEmpty(str_email) || TextUtils.isEmpty(str_password)){
                    Toast.makeText(login.this, "Please enter all fileds!", Toast.LENGTH_SHORT).show();
                }
                else{
                    firebase.signInWithEmailAndPassword(str_email,str_password)
                            .addOnCompleteListener(login.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                                    if(task.isSuccessful()){
                                        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("Users").child(firebase.getCurrentUser().getUid());
                                        reference.addValueEventListener(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                                                pd.dismiss();//end the dialog.
                                                Intent intent = new Intent(login.this, Home.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);
                                                finish();
                                            }

                                            @Override
                                            public void onCancelled(@NonNull @NotNull DatabaseError error) {
                                                pd.dismiss();//end the dialog.
                                            }
                                        });
                                    }else{
                                        pd.dismiss();//end the dialog.
                                        Toast.makeText(login.this, "Faild!", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });

        Signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(login.this,Signup.class));
            }
        });
    }
/*
    private void validvalue(String name, String password){
        ProDialog.setMessage("Just a moment");
        ProDialog.show();
        Task<AuthResult> authResultTask = firebase.signInWithEmailAndPassword(name, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<AuthResult> task) {
                if (task.isSuccessful()) {
                    ProDialog.dismiss();//end the dialog.
                    Intent intent = new Intent(login.this, Home.class);
                    Toast.makeText(login.this, "Login success", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                } else {
                    ProDialog.dismiss();//end the dialog.
                    Toast.makeText(login.this, "Login failed", Toast.LENGTH_SHORT).show();
                    counter--;
                    if (counter == 0) {
                        Info.setText("You’ve reached the maximum login attempts");
                        Login.setEnabled(false);
                    }
                }
            }
        });
    }
*/
}