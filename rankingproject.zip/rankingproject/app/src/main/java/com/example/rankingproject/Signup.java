package com.example.rankingproject;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class Signup extends AppCompatActivity {


    private EditText username, Password, Email;//spots to put the info.
    private TextView Login;
    private Button BTSsignup;
    private FirebaseAuth firebase;
    private DatabaseReference reference;//write reference and no databaseRefrence.
    private ProgressDialog pd;//to the Toast.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);//all the varibals.
        BTSsignup = (Button) findViewById(R.id.BTSsignup);
        username = (EditText) findViewById(R.id.username);
        Password = (EditText) findViewById(R.id.TSpassword);
        Email = (EditText) findViewById(R.id.Temail);
        Login = (TextView) findViewById(R.id.TValreadyhave);
        firebase = FirebaseAuth.getInstance();
        BTSsignup.setOnClickListener(new View.OnClickListener() {//when press the sign up button.
            @Override
            public void onClick(View v) {
                pd = new ProgressDialog(Signup.this);//make new dialog.
                pd.setMessage("please wait...");
                pd.show();//show the message.
                //save the user info in String.
                String str_username = username.getText().toString();
                String str_email = Email.getText().toString();
                String str_password = Password.getText().toString();

                if (TextUtils.isEmpty(str_username) || TextUtils.isEmpty(str_email) || TextUtils.isEmpty(str_password)) {//if not all the field are full.
                    Toast.makeText(Signup.this, "Please put all details!", Toast.LENGTH_SHORT).show();
                } else if (str_password.length() < 6) {//if the password is less the 6 characters.
                    Toast.makeText(Signup.this, "Password need to be more then 6 characters!", Toast.LENGTH_SHORT).show();
                } else {//sign up.
                    register(str_username, str_email, str_password);
                }
            }
        });
        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Signup.this, login.class));
            }
        });
    }

    private void register(String name, String email, String password) {//sign up function.
        firebase.createUserWithEmailAndPassword(email, password)//create a user.
                .addOnCompleteListener(Signup.this, new OnCompleteListener<AuthResult>() {//listen to when user create complete.
                    @Override
                    public void onComplete(@NonNull @NotNull Task<AuthResult> task) {//when complete.
                        if (task.isSuccessful()) {//if the user has been create successfully.
                            FirebaseUser firebaseUser = firebase.getCurrentUser();//get the current user.
                            String userid = firebaseUser.getUid();//get user id.
                            reference = FirebaseDatabase.getInstance().getReference().child("Users").child(userid);//get a reference to the user.
                            HashMap<String, Object> hashMap = new HashMap<>();//save the information in the data base.
                            hashMap.put("id", userid);//save in the user id.
                            hashMap.put("username", name);
                            hashMap.put("email", email);
                            hashMap.put("password", password);
                            hashMap.put("imageurl", "https://firebasestorage.googleapis.com/v0/b/rakingproject.appspot.com/o/%5BBZ%5D%20white%20and%20black%201.jpg?alt=media&token=45725607-5c9f-42fc-8aa7-e7d3e6936bfb");
                            reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {//listen to when the information in the data base save.
                                @Override
                                public void onComplete(@NonNull @NotNull Task<Void> task) {
                                    if (task.isSuccessful()) {//if the information saved successfully.
                                        pd.dismiss();//end the dialog.
                                        Intent intent = new Intent(Signup.this, Home.class);//make a new intent from sing up to the home screnn.
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);//add the flags.
                                        startActivity(intent);//start the intent.
                                    }
                                }
                            });
                        } else {//if the user has not been create.
                            pd.dismiss();//end the dialog.
                            Toast.makeText(Signup.this, "Sign Up Failed", Toast.LENGTH_SHORT).show();//show a message that say that the sign up didn't work.
                        }
                    }

                });

        /*
        BTSsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validvalue()){//upload data to data base.
                    String UserEmail = Email.getText().toString();
                    String UserPassword = Password.getText().toString();
                    firebase.createUserWithEmailAndPassword(UserEmail,UserPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NotNull Task<AuthResult> task) {
                            Toast.makeText(Signup.this, "" + task.isSuccessful(), Toast.LENGTH_SHORT).show();
                            if(task.isSuccessful()){
                                Toast.makeText(Signup.this, "Sign Up Successful", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Signup.this, Home.class));
                            }
                            else{
                                Toast.makeText(Signup.this, "Sign Up Failed", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });



    }

    private void EmailVerification(){
        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        user.sendEmailVerification()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Log.d("TAG", "Email sent.");
                        }
                    }
                });
    }
 private boolean validvalue(){
        String name = Name.getText().toString();
        String password = Password.getText().toString();
        String email = Email.getText().toString();
        if(name.isEmpty() || password.isEmpty() || email.isEmpty()){
            Toast.makeText(this,"Please put all details",Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    } */


    }
}